package com.loan.loan.management.system.Service;

import com.loan.loan.management.system.Entity.CustomersLoan;
import com.loan.loan.management.system.Entity.RepaymentSchedule;
import com.loan.loan.management.system.Repository.RepaymentScheduleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RepaymentScheduleService {
    private final RepaymentScheduleRepository repaymentScheduleRepository;

    public RepaymentSchedule create(RepaymentSchedule repaymentSchedule){
        repaymentSchedule.setId(null);
        return repaymentScheduleRepository.save(repaymentSchedule);
    }

    public List<RepaymentSchedule> getAll(){
        return repaymentScheduleRepository.findAll();
    }

    public RepaymentSchedule getById(Long id){
        return repaymentScheduleRepository.getReferenceById(id);
    }

    public RepaymentSchedule update(Long id,RepaymentSchedule repaymentSchedule){
        RepaymentSchedule existing=getById(id);

        existing.setInstallmentNumber(repaymentSchedule.getInstallmentNumber());
        existing.setDueDate(repaymentSchedule.getDueDate());
        existing.setEmiAmount(repaymentSchedule.getEmiAmount());
        existing.setPrincipalComponent(repaymentSchedule.getPrincipalComponent());
        existing.setInterestComponent(repaymentSchedule.getInterestComponent());
        existing.setOutstandingPrincipal(repaymentSchedule.getOutstandingPrincipal());
        existing.setStatus(repaymentSchedule.getStatus());

        return repaymentScheduleRepository.save(existing);
    }

    public void delete(Long id){
        repaymentScheduleRepository.deleteById(id);
    }
}
