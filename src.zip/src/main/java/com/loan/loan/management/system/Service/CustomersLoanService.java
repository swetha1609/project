package com.loan.loan.management.system.Service;



import com.loan.loan.management.system.Entity.CustomersLoan;
import com.loan.loan.management.system.Repository.CustomersLoanRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
public class CustomersLoanService {
    private final CustomersLoanRepository customersLoanRepository;

    public CustomersLoan create(CustomersLoan customersLoan){
        customersLoan.setId(null);
        return customersLoanRepository.save(customersLoan);
    }

    public List<CustomersLoan> getAll(){
        return customersLoanRepository.findAll();
    }

    public CustomersLoan getById(Long id){
        return customersLoanRepository.getReferenceById(id);
    }

    public CustomersLoan update(Long id,CustomersLoan customersLoan){
        CustomersLoan existing=getById(id);

        existing.setCustomerName(customersLoan.getCustomerName());
        existing.setPrincipalAmount(customersLoan.getPrincipalAmount());
        existing.setStartDate(customersLoan.getStartDate());
        existing.setEndDate(customersLoan.getEndDate());
        existing.setStatus(customersLoan.getStatus());

        return customersLoanRepository.save(existing);
    }

    public void delete(Long id){
        customersLoanRepository.deleteById(id);
    }
}
