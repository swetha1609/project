package com.loan.loan.management.system.Controller;

import com.loan.loan.management.system.Entity.LoanProduct;
import com.loan.loan.management.system.Service.LoanProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/product")
@RequiredArgsConstructor
public class LoanProductController {
    private final LoanProductService loanProductService;

    @PostMapping
    public LoanProduct createproduct(@Valid @RequestBody LoanProduct loanProduct){
        return loanProductService.create(loanProduct);
    }

    @GetMapping
    public List<LoanProduct> GetAll(){
        return loanProductService.getAll();
    }

    @GetMapping("/{id}")
    public LoanProduct GetById(@PathVariable Long id){
        return loanProductService.getById(id);
    }

    @PutMapping("/{id}")
    public LoanProduct updateproduct(@PathVariable Long id,@Valid @RequestBody LoanProduct loanProduct){
        return loanProductService.update(id,loanProduct);
    }

    @DeleteMapping("/{id}")
    public String Delete(@PathVariable Long id){
         loanProductService.delete(id);
         return "Successfully Deleted.";
    }
}
