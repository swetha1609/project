package com.loan.loan.management.system.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "loanProduct")
public class LoanProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Product_id")
    private Long id;

    @NotBlank(message = "Product name is required")
    @Column (name = "Product_name")
    private String productName;

    @NotNull(message = "interest rate is required")
    @Column(name="InterestRate")
    private BigDecimal interestRate;

    @NotNull(message = "number of repayment is required")
    @Column(name="NumberOfRepayments")
    private Integer numberOfRepayments;

    @NotNull(message = "Day count convention is required")
    @Enumerated(EnumType.STRING)
    @Column(name = "Day_CountConvention")
    private DayCountConvention dayCountConvention;

    public enum DayCountConvention {
        ACTUAL_360,
        ACTUAL_365,
        THIRTY_360
    }

    @OneToMany(mappedBy = "loanProduct")
    @JsonIgnore
    private List<CustomersLoan> customersLoans = new ArrayList<>();

    public LoanProduct(){}
    public LoanProduct(Long id,String productName,BigDecimal interestRate,Integer numberOfRepayments,DayCountConvention dayCountConvention){
        this.id = id;
        this.productName = productName;
        this.interestRate = interestRate;
        this.numberOfRepayments = numberOfRepayments;
        this.dayCountConvention = dayCountConvention;
    }
    public Long getId() {return id;}
    public void setId(Long id) {this.id = id;}

    public String getProductName() {return productName;}
    public void setProductName(String productName) {this.productName = productName;}

    public BigDecimal getInterestRate() {return interestRate;}
    public void setInterestRate(BigDecimal interestRate) {this.interestRate = interestRate;}

    public Integer getNumberOfRepayments() {return numberOfRepayments;}
    public void setNumberOfRepayments(Integer numberOfRepayments) {this.numberOfRepayments = numberOfRepayments;}

    public DayCountConvention getDayCountConvention() {return dayCountConvention;}
    public void setDayCountConvention(DayCountConvention dayCountConvention) {this.dayCountConvention = dayCountConvention;}

    public List<CustomersLoan> getCustomersLoans() {return customersLoans;}
    public void setCustomersLoans(List<CustomersLoan> customersLoans) {this.customersLoans = customersLoans;}
}
