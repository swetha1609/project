package com.loan.loan.management.system.Service;


import com.loan.loan.management.system.Entity.Transaction;
import com.loan.loan.management.system.Repository.CustomersLoanRepository;
import com.loan.loan.management.system.Repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepository transactionRepository;

    public Transaction create(Transaction transaction){
        transaction.setId(null);
        return transactionRepository.save(transaction);
    }

    public List<Transaction> getAll(){
        return transactionRepository.findAll();
    }

    public Transaction getById(Long id){
        return transactionRepository.getReferenceById(id);
    }

    public Transaction update(Long id,Transaction transaction){
        Transaction existing=getById(id);

        existing.setTransactionDate(transaction.getTransactionDate());
        existing.setAmountPaid(transaction.getAmountPaid());

        return transactionRepository.save(existing);
    }

    public void delete(Long id){
        transactionRepository.deleteById(id);
    }
}
