package com.loan.loan.management.system.Controller;


import com.loan.loan.management.system.Entity.Transaction;
import com.loan.loan.management.system.Service.TransactionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transaction")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;

    @PostMapping
    public Transaction create(@Valid @RequestBody Transaction transaction){
        return transactionService.create(transaction);
    }

    @GetMapping
    public List<Transaction> GetAll(){
        return transactionService.getAll();
    }

    @GetMapping("/{id}")
    public Transaction GetById(@PathVariable Long id){
        return transactionService.getById(id);
    }

    @PutMapping("/{id}")
    public Transaction updateproduct(@PathVariable Long id,@Valid @RequestBody Transaction transaction) {
        return transactionService.update(id, transaction);
    }

    @DeleteMapping("/{id}")
    public String Delete(@PathVariable Long id){
        transactionService.delete(id);
        return "Successfully Deleted.";
    }
}
