package com.loan.loan.management.system.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "CustomersLoan")
public class CustomersLoan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Customer_id")
    private Long id;

    @NotBlank(message = "Customer  name is required")
    @Column (name = "Customer_name")
    private String customerName;

    @NotNull(message = "interest rate is required")
    @Column(name="Principle_Amount")
    private BigDecimal principalAmount;

    @NotNull(message = "date is required")
    @Column(name="Start_Date")
    private LocalDate startDate;

    @NotNull(message = "date is required")
    @Column(name="End_Date")
    private LocalDate endDate;

    @NotBlank(message = "Status is required")
    @Column(name="Status")
    private String status;

    @OneToMany(mappedBy = "customersLoan")
    @JsonIgnore
    private List<RepaymentSchedule>repaymentSchedules=new ArrayList<>();

    @OneToMany(mappedBy = "customersLoan")
    @JsonIgnore
    private List<Transaction> transactions=new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "Product_id")
    @JsonIgnoreProperties("customersLoan")
    private LoanProduct loanProduct;

    public CustomersLoan() {
    }

    public CustomersLoan(Long id, String customerName, BigDecimal principalAmount, LocalDate startDate, LocalDate endDate, String status) {
        this.id = id;
        this.customerName = customerName;
        this.principalAmount = principalAmount;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public BigDecimal getPrincipalAmount() {
        return principalAmount;
    }

    public void setPrincipalAmount(BigDecimal principalAmount) {
        this.principalAmount = principalAmount;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<RepaymentSchedule> getRepaymentSchedules() {
        return repaymentSchedules;
    }

    public void setRepaymentSchedules(List<RepaymentSchedule> repaymentSchedules) {
        this.repaymentSchedules = repaymentSchedules;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public LoanProduct getLoanProduct() {
        return loanProduct;
    }

    public void setLoanProduct(LoanProduct loanProduct) {
        this.loanProduct = loanProduct;
    }



}
