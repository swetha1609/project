package com.loan.loan.management.system.Controller;

import com.loan.loan.management.system.Entity.CustomersLoan;
import com.loan.loan.management.system.Entity.LoanProduct;
import com.loan.loan.management.system.Service.CustomersLoanService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@RequiredArgsConstructor
public class CustomersLoanController {
    private final CustomersLoanService customersLoanService;

    @PostMapping
    public CustomersLoan create(@Valid @RequestBody CustomersLoan customersLoan){
        return customersLoanService.create(customersLoan);
    }

    @GetMapping
    public List<CustomersLoan> GetAll(){
        return customersLoanService.getAll();
    }

    @GetMapping("/{id}")
    public CustomersLoan GetById(@PathVariable Long id){
        return customersLoanService.getById(id);
    }

    @PutMapping("/{id}")
    public CustomersLoan updateproduct(@PathVariable Long id,@Valid @RequestBody CustomersLoan customersLoan){
        return customersLoanService.update(id,customersLoan);
    }

    @DeleteMapping("/{id}")
    public String Delete(@PathVariable Long id){
        customersLoanService.delete(id);
        return "Successfully Deleted.";
    }
}
