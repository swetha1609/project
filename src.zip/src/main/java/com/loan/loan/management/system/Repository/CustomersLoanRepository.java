package com.loan.loan.management.system.Repository;

import com.loan.loan.management.system.Entity.CustomersLoan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomersLoanRepository extends JpaRepository<CustomersLoan,Long> {
}
