package com.loan.loan.management.system.Service;

import com.loan.loan.management.system.Entity.LoanProduct;
import com.loan.loan.management.system.Repository.LoanProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class LoanProductService {
    private final LoanProductRepository loanProductRepository;

    public LoanProduct create(LoanProduct loanProduct){
        loanProduct.setId(null);
        return loanProductRepository.save(loanProduct);
    }

    public List<LoanProduct> getAll(){
        return loanProductRepository.findAll();
    }

    public LoanProduct getById(Long id){
        return loanProductRepository.getReferenceById(id);
    }

    public LoanProduct update(Long id,LoanProduct loanProduct){
        LoanProduct existing=getById(id);

        existing.setProductName(loanProduct.getProductName());
        existing.setInterestRate(loanProduct.getInterestRate());
        existing.setNumberOfRepayments(loanProduct.getNumberOfRepayments());
        existing.setDayCountConvention(loanProduct.getDayCountConvention());

        return loanProductRepository.save(existing);
    }

    public void delete(Long id){
        loanProductRepository.deleteById(id);
    }
}
