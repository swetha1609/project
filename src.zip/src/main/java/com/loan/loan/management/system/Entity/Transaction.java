package com.loan.loan.management.system.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;


@Entity
@Table(name="Transaction")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Transaction_id")
    private Long id;

    @NotNull(message = "Transaction Date is required")
    @Column(name="Transaction_date")
    private LocalDate transactionDate;

    @NotNull(message = "Amount paid is required")
    @Column(name="amount_paid")
    private BigDecimal amountPaid ;

    @ManyToOne
    @JoinColumn(name = "Customer_id")
    @JsonIgnoreProperties("transactions")
    private CustomersLoan customersLoan;

    public Transaction() {
    }

    public Transaction(Long id, LocalDate transactionDate, BigDecimal amountPaid) {
        this.id = id;
        this.transactionDate = transactionDate;
        this.amountPaid = amountPaid;
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getTransactionDate() {
        return transactionDate;
    }
    public void setTransactionDate(LocalDate transactionDate) {
        this.transactionDate = transactionDate;
    }

    public BigDecimal getAmountPaid() {
        return amountPaid;
    }
    public void setAmountPaid(BigDecimal amountPaid) {
        this.amountPaid = amountPaid;
    }

    public CustomersLoan getCustomersLoan() {return customersLoan;}
    public void setCustomersLoan(CustomersLoan customersLoan) {this.customersLoan = customersLoan;}

}
