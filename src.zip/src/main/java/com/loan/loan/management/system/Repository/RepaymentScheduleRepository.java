package com.loan.loan.management.system.Repository;

import com.loan.loan.management.system.Entity.RepaymentSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepaymentScheduleRepository extends JpaRepository<RepaymentSchedule,Long> {
}
