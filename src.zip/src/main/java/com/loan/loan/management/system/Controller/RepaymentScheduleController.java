package com.loan.loan.management.system.Controller;


import com.loan.loan.management.system.Entity.RepaymentSchedule;
import com.loan.loan.management.system.Service.RepaymentScheduleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/repayment")
@RequiredArgsConstructor
public class RepaymentScheduleController {
    private final RepaymentScheduleService repaymentScheduleService;

    @PostMapping
    public RepaymentSchedule create(@Valid @RequestBody RepaymentSchedule repaymentSchedule){
        return repaymentScheduleService.create(repaymentSchedule);
    }

    @GetMapping
    public List<RepaymentSchedule> GetAll(){
        return repaymentScheduleService.getAll();
    }

    @GetMapping("/{id}")
    public RepaymentSchedule GetById(@PathVariable Long id){
        return repaymentScheduleService.getById(id);
    }

    @PutMapping("/{id}")
    public RepaymentSchedule updateproduct(@PathVariable Long id,@Valid @RequestBody RepaymentSchedule repaymentSchedule){
        return repaymentScheduleService.update(id,repaymentSchedule);
    }

    @DeleteMapping("/{id}")
    public String Delete(@PathVariable Long id){
        repaymentScheduleService.delete(id);
        return "Successfully Deleted.";
    }
}
